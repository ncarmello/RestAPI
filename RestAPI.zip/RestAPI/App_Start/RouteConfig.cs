﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace RestAPI
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );

            /*
1. List all cities in a state

	`GET /state/{state}/cities`
 
2. Allow to create rows of data to indicate they have visited a particular city.

	`POST /user/{user}/visits`

	```
	{
		"city": "Chicago",
		"state": "IL"
	}
	```
	
3. Allow a user to remove an improperly pinned visit.

	`DEL /user/{user}/visit/{visit}

4. Return a list of cities the user has visited

	`GET /user/{user}/visits
	
5. Return a list of states the user has visited

	`GET /user/{user}/visits/states
    */
            routes.MapRoute(
                name: "CitiesInState",
                url: "{controller}/{id}/cities",
                defaults: new { id = "1" }
            );
            routes.MapRoute(
                name: "AddUserVisit",
                url: "{controller}/{id}/visits",
                defaults: new { id = "1" }
            );
            routes.MapRoute(
                name: "DeleteVisit",
                url: "{controller}/{userid}/visit/{visitid}",
                defaults: new { userid = "1", visitid = "0" }
            );
            routes.MapRoute(
                name: "GetUserVisits",
                url: "{controller}/{id}/visits",
                defaults: new { action = "Index", id = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "GetUserVisitsStates",
                url: "{controller}/{user}/visits/states",
                defaults: new { userid = "1" }
            );
        }
    }
}
