﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RestAPI.Models;

namespace RestAPI.Controllers
{
    public class StateController : ApiController
    {
        private RestAPIEntities db = new RestAPIEntities();

        // GET api/<controller>/5
        [Route("state/{stateid}/cities")]
        public IQueryable<CityInfo> GetCitiesInState(int stateid)
        {
            var cities = from rs in db.Cities
                         where rs.StateID == stateid
                         select new CityInfo()
                         {
                             ID = rs.ID,
                             Name = rs.Name,
                             StateID = rs.StateID,
                             State = rs.State.Name,
                             Abbr = rs.State.Abbreviation,
                             Longitude = rs.Longitude,
                             Latitude = rs.Latitude
                         };
            return cities;  
        }

        // GET api/<controller>/5
        [Route("state")]
        public IQueryable<StateInfo> GetStates()
        {
            var states = from rs in db.States
                         select new StateInfo()
                         {
                            ID = rs.ID,
                            Name = rs.Name,
                            Abbr = rs.Abbreviation
                         };
            return states;
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}
