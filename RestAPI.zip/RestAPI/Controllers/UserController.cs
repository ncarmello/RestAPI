﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using RestAPI.Models;

namespace RestAPI.Controllers
{
    public class UsersController : ApiController
    {
        private RestAPIEntities db = new RestAPIEntities();

        public UsersController()
        {
            db.Configuration.LazyLoadingEnabled = false;
            db.Configuration.ProxyCreationEnabled = false;
        }

        // GET: api/NewUsers
        [Route("user")]
        public IQueryable<UserInfo> GetUsers()
        {
            var users = from rs in db.Users
                        select new UserInfo()
                        {
                            ID = rs.ID,
                            Firstname = rs.FirstName,
                            Lastname = rs.LastName,
                            DateAdded = rs.DateAdded,
                            DateTimeAdded = rs.DateTimeAdded,
                            LastUpdated = rs.LastUpdated
                        };
            return users;
        }

        // GET: api/NewUsers/5
        [ResponseType(typeof(UserInfo))]
        [Route("user/{id}")]
        public async Task<IHttpActionResult> GetUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            UserInfo info;
            if (user == null)
            {
                return NotFound();
            }
            else
            {
                info = new UserInfo();
                info.ID = user.ID;
                info.Firstname = user.FirstName;
                info.Lastname = user.LastName;
                info.DateAdded = user.DateAdded;
                info.DateTimeAdded = user.DateTimeAdded;
                info.LastUpdated = user.LastUpdated;
            }
            return Ok(info);
        }

        // PUT: api/NewUsers/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutUser(int id, User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != user.ID)
            {
                return BadRequest();
            }

            db.Entry(user).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/NewUsers
        [ResponseType(typeof(User))]
        public async Task<IHttpActionResult> PostUser(User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Users.Add(user);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = user.ID }, user);
        }

        // DELETE: api/NewUsers/5
        [ResponseType(typeof(User))]
        [HttpDelete]
        [Route("user/{id}")]
        public async Task<IHttpActionResult> DeleteUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            db.Users.Remove(user);
            await db.SaveChangesAsync();

            return Ok(user);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UserExists(int id)
        {
            return db.Users.Count(e => e.ID == id) > 0;
        }
    }
}