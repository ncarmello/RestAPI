﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace RestAPI.Models
{
    public class NewUsersController : ApiController
    {
        private RestAPIEntities db = new RestAPIEntities();

        public NewUsersController()
        {
            //db.Configuration.LazyLoadingEnabled = false;
            //db.Configuration.ProxyCreationEnabled = false;
        }

        // GET: api/NewUsers
        [Route("newuser")]
        public IQueryable<User> GetUsers()
        {
            return db.Users;
        }

        // GET: api/NewUsers/5
        [ResponseType(typeof(UserInfo))]
        [Route("newuser/{id}")]
        public async Task<IHttpActionResult> GetUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            UserInfo info;
            if (user == null)
            {
                return NotFound();
            }
            else
            {
                info = new UserInfo();
                info.ID = user.ID;
                info.Firstname = user.FirstName;
                info.Lastname = user.LastName;
                info.DateAdded = user.DateAdded;
                info.DateTimeAdded = user.DateTimeAdded;
                info.LastUpdated = user.LastUpdated;
            }
            return Ok(info);
        }

        // GET: api/NewUsers/5
        //[ResponseType(typeof(City))]
        [Route("newuser/{userid}/visits")]
        public IQueryable<CityVisit> GetCitiesVisited(int userid)
        {
            var cities = from rs in db.Visits
                         where rs.UsersID == userid
                         select new CityVisit()
                         {
                             VisitID = rs.ID,
                             City = rs.City.Name,
                             UsersID = rs.UsersID,
                             Longitude = rs.City.Longitude,
                             Latitude = rs.City.Latitude,
                             VisitDate = rs.VisitDate
                         };

            return cities;
        }

        // GET: api/NewUsers/5
        //[ResponseType(typeof(User))]
        [Route("newuser/{userid}/visits/states")]
        public IQueryable<StateVisit> GetStatesVisited(int userid)
        {
            var states = from rs in db.Visits
                         where rs.UsersID == userid
                         select new StateVisit()
                         {
                             VisitID = rs.ID,
                             State = rs.City.State.Name,
                             UsersID = rs.UsersID,
                             VisitDate = rs.VisitDate
                         };

            return states;
        }

        // PUT: api/NewUsers/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutUser(int id, User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != user.ID)
            {
                return BadRequest();
            }

            db.Entry(user).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/NewUsers
        [ResponseType(typeof(User))]
        public async Task<IHttpActionResult> PostUser(User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Users.Add(user);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = user.ID }, user);
        }

        // DELETE: api/NewUsers/5
        [ResponseType(typeof(User))]
        [HttpDelete]
        [Route("newuser/{id}")]
        public async Task<IHttpActionResult> DeleteUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            db.Users.Remove(user);
            await db.SaveChangesAsync();

            return Ok(user);
        }

        // POST: api/NewUsers
        [ResponseType(typeof(Visit))]
        [Route("newuser/{userid}/visits")]
        public async Task<IHttpActionResult> PostVisit(Visit visit)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Visits.Add(visit);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = visit.ID }, visit);
        }

        // DELETE: api/NewUsers/5
        [ResponseType(typeof(Visit))]
        [Route("newuser/{userid}/visit/{visitid}")]
        public async Task<IHttpActionResult> DeleteVisit(int userid, int visitid)
        {
            User user = await db.Users.FindAsync(userid);
            Visit visit = await db.Visits.FindAsync(visitid);
            if (null == visit || null == user)
            {
                return NotFound();
            }

            db.Visits.Remove(visit);
            await db.SaveChangesAsync();

            return Ok(visit);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UserExists(int id)
        {
            return db.Users.Count(e => e.ID == id) > 0;
        }
    }
}