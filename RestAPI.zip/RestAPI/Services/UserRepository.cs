﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RestAPI.Models;

namespace RestAPI.Services
{
    public class UserRepository
    {
        RestAPIEntities context;

        public UserRepository()
        {
            context = new RestAPIEntities();
        }

        public IEnumerable<User> GetAllUsers()
        {
            return context.Users.ToList<User>();
        }

        public User GetUser(int id)
        {
            return context.Users.Where(x => x.ID == id).FirstOrDefault<User>();
        }

        public int CreateUser(User user)
        {
            User u = context.Users.Add(user);
            context.SaveChangesAsync();
            return u.ID;
        }

        public bool DeleteUser(int id)
        {
            var user = context.Users.Where(x => x.ID == id).FirstOrDefault<User>();
            context.Users.Remove(user);
            context.SaveChangesAsync();
            return true;
        }

        public IEnumerable<City> GetCitiesVisited(int id)
        {
            List<City> cities = new List<City>();
            var user = context.Users.Where(x => x.ID == id).FirstOrDefault<User>();
            var visits = user.Visits;
            foreach(Visit v in visits)
            {
                cities.Add(v.City);
            }
            return cities;
        }

        public IEnumerable<State> GetStatesVisited(int id)
        {
            List<State> states = new List<State>();
            var user = context.Users.Where(x => x.ID == id).FirstOrDefault<User>();
            var visits = user.Visits;
            foreach (Visit v in visits)
            {
                if(!states.Contains<State>(v.City.State))
                    states.Add(v.City.State);
            }
            return states;
        }

        public bool DeleteVisit(int id)
        {
            var visit = context.Visits.Where(x => x.ID == id).FirstOrDefault<Visit>();
            context.Visits.Remove(visit);
            context.SaveChangesAsync();
            return true;
        }
    }
}